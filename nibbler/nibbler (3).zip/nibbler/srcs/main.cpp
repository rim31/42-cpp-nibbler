#include "GraphicsHandler.hpp"

int main(void)
{
	GraphicsHandler	*guiHandler = new GraphicsHandler();
	guiHandler->loadLibrary("libs/libsdl/libsdl.so");

	std::list<std::list<t_blocks>>	& map = guiHandler->guiInst->map;
	std::list<std::list<t_blocks>> mapTmp;

	for (int y = 0; y < HEIGHT; ++y)
	{
		std::list<t_blocks> line;

		for (int x = 0; x < WIDTH; ++x)
		{
			// if (x == snakeHead.x && y == snakeHead.y)
			// 	line.push_back(HEAD);
			// else
				line.push_back(BLKNONE);
		}
		map.push_back(line);
	}


	///////////////////////////////////////////////////////////////////////////

	// for (int y = 0; y < 10; ++y)
	// {
	// 	std::list<t_blocks> line;

	// 	for (int x = 0; x < 10; ++x)
	// 		line.push_back(WALL);
	// 	map.push_back(line);
	// }

	while (1)
	{
		guiHandler->guiInst->update();
		switch (guiHandler->guiInst->glib_action)
		{
			case LIB1:
				mapTmp = guiHandler->guiInst->map;
				if (guiHandler != NULL)
					delete guiHandler;

				guiHandler = new GraphicsHandler();
				guiHandler->loadLibrary("libs/libsdl/libsdl.so");
				guiHandler->guiInst->glib_action = NONE;
				guiHandler->guiInst->map = mapTmp;
				break;
			case LIB2:
				mapTmp = guiHandler->guiInst->map;
				if (guiHandler != NULL)
					delete guiHandler;

				guiHandler = new GraphicsHandler();
				guiHandler->loadLibrary("libs/libncurses/libncurses.so");
				guiHandler->guiInst->glib_action = NONE;
				guiHandler->guiInst->map = mapTmp;
				break;
				// =====================
			case UP:
				break;
			case LEFT:
				break;
			case DOWN:
				break;
			case RIGHT:
				break;
				// =====================
			case QUIT:
				if (guiHandler != NULL)
					delete guiHandler;
				exit(0);
				break;
			case NONE:
				break;
		}
	}

	return 0;
}
